Sample configuration files for:
```
SystemD: litbiad.service
Upstart: litbiad.conf
OpenRC:  litbiad.openrc
         litbiad.openrcconf
CentOS:  litbiad.init
macOS:    org.litbia.litbiad.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
